import RegistrationField from "../../shared/components/FormField";

function EventSchedule({ form, errors, onChange }) {
  return (
    <section className="sr-form-section" aria-label="Event schedule">
      <div className="sr-section-heading">
        <div>
          <h3>Event schedule</h3>
          <p>Set the dates and times your event will run.</p>
        </div>
      </div>
      <div className="sr-fields-grid">
        <RegistrationField
          label="Start date *"
          name="scheduleStartDate"
          error={errors.scheduleStartDate}
        >
          <input
            id="scheduleStartDate"
            name="scheduleStartDate"
            type="date"
            value={form.scheduleStartDate}
            onChange={onChange}
            aria-invalid={Boolean(errors.scheduleStartDate)}
            required
          />
        </RegistrationField>
        <RegistrationField
          label="End date *"
          name="scheduleEndDate"
          error={errors.scheduleEndDate}
        >
          <input
            id="scheduleEndDate"
            name="scheduleEndDate"
            type="date"
            min={form.scheduleStartDate || undefined}
            value={form.scheduleEndDate}
            onChange={onChange}
            aria-invalid={Boolean(errors.scheduleEndDate)}
            required
          />
        </RegistrationField>
        <RegistrationField
          label="Event start time *"
          name="startTime"
          error={errors.startTime}
        >
          <input
            id="startTime"
            name="startTime"
            type="time"
            value={form.startTime}
            onChange={onChange}
            aria-invalid={Boolean(errors.startTime)}
            required
          />
        </RegistrationField>
        <RegistrationField
          label="Event end time *"
          name="endTime"
          error={errors.endTime}
        >
          <input
            id="endTime"
            name="endTime"
            type="time"
            value={form.endTime}
            onChange={onChange}
            aria-invalid={Boolean(errors.endTime)}
            required
          />
        </RegistrationField>
      </div>
    </section>
  );
}

export default EventSchedule;
