import RegistrationField from "../../shared/components/FormField";

function EventDetails({ config, form, errors, onChange }) {
  return (
    <>
      <div className="sr-fields-grid">
        <RegistrationField
          label={`${config.nameLabel} *`}
          name={config.nameField}
          error={errors[config.nameField]}
        >
          <input
            id={config.nameField}
            name={config.nameField}
            value={form[config.nameField]}
            onChange={onChange}
            maxLength={100}
            aria-invalid={Boolean(errors[config.nameField])}
            required
          />
        </RegistrationField>
        <RegistrationField
          label={`${config.capacityLabel} *`}
          name={config.capacityField}
          error={errors[config.capacityField]}
        >
          <input
            id={config.capacityField}
            name={config.capacityField}
            type="number"
            min="1"
            max="10000"
            value={form[config.capacityField]}
            onChange={onChange}
            aria-invalid={Boolean(errors[config.capacityField])}
            required
          />
          <small>{config.capacityHelp}</small>
        </RegistrationField>
      </div>
      <RegistrationField
        label={`${config.descriptionLabel} *`}
        name={config.descriptionField}
        error={errors[config.descriptionField]}
      >
        <textarea
          id={config.descriptionField}
          name={config.descriptionField}
          value={form[config.descriptionField]}
          onChange={onChange}
          maxLength={500}
          rows={4}
          placeholder="Describe your event"
          aria-invalid={Boolean(errors[config.descriptionField])}
          required
        />
      </RegistrationField>
      <div className="sr-fields-grid">
        <RegistrationField
          label="Ticket price (₹) *"
          name="ticketPrice"
          error={errors.ticketPrice}
        >
          <input
            id="ticketPrice"
            name="ticketPrice"
            type="number"
            min="0"
            step="0.01"
            value={form.ticketPrice}
            onChange={onChange}
            placeholder="0.00"
            aria-invalid={Boolean(errors.ticketPrice)}
            required
          />
        </RegistrationField>
        <RegistrationField
          label="Timeline *"
          name="timeline"
          error={errors.timeline}
        >
          <input
            id="timeline"
            name="timeline"
            value={form.timeline}
            onChange={onChange}
            maxLength={100}
            placeholder="For example: One day / Weekend"
            aria-invalid={Boolean(errors.timeline)}
            required
          />
        </RegistrationField>
      </div>
      <fieldset
        className="event-package-options"
        aria-invalid={Boolean(errors[config.categoryField])}
        aria-describedby={
          errors[config.categoryField] ? `${config.categoryField}-error` : undefined
        }
      >
        <legend>Select your event category *</legend>
        <p>Choose a package for your event.</p>
        <div className="event-package-grid">
          {config.categories.map((category) => (
            <label
              className={`event-package-card event-package-${category.toLowerCase()}`}
              key={category}
            >
              <input
                type="radio"
                name={config.categoryField}
                value={category}
                checked={form[config.categoryField] === category}
                onChange={onChange}
                required
              />
              <span className="event-package-badge">{category}</span>
              <strong>{category}</strong>
              <span className="event-package-description">
                {category === "Platinum"
                  ? "Premium event package"
                  : category === "Gold"
                    ? "Enhanced event package"
                    : "Essential event package"}
              </span>
            </label>
          ))}
        </div>
        {errors[config.categoryField] && (
          <span
            className="sr-field-error"
            id={`${config.categoryField}-error`}
            role="alert"
          >
            {errors[config.categoryField]}
          </span>
        )}
      </fieldset>
    </>
  );
}

export default EventDetails;
