import eventsRegistrationConfig from "./eventsConfig";
import { validateForm } from "../shared/utils/formUtils";

const isValidDate = (value) => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
};

export const validateEventRegistration = (form, agreedToTerms) => {
  const errors = validateForm(form, eventsRegistrationConfig, agreedToTerms);
  const ticketPrice =
    typeof form.ticketPrice === "string" ? form.ticketPrice.trim() : "";
  const ticketPriceAmount = Number(ticketPrice);
  if (
    !/^\d+(?:\.\d{1,2})?$/.test(ticketPrice) ||
    !Number.isFinite(ticketPriceAmount) ||
    ticketPriceAmount < 0
  ) {
    errors.ticketPrice = "Enter a ticket price of ₹0 or more with up to 2 decimal places.";
  }
  const timeline = typeof form.timeline === "string" ? form.timeline.trim() : "";
  if (timeline.length < 2 || timeline.length > 100) {
    errors.timeline = "Enter a timeline between 2 and 100 characters.";
  }
  if (!isValidDate(form.scheduleStartDate)) {
    errors.scheduleStartDate = "Enter a valid event start date.";
  }
  if (!isValidDate(form.scheduleEndDate)) {
    errors.scheduleEndDate = "Enter a valid event end date.";
  } else if (
    isValidDate(form.scheduleStartDate) &&
    form.scheduleEndDate < form.scheduleStartDate
  ) {
    errors.scheduleEndDate = "End date must be on or after the start date.";
  }
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(form.startTime)) {
    errors.startTime = "Enter a valid event start time.";
  }
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(form.endTime)) {
    errors.endTime = "Enter a valid event end time.";
  } else if (
    form.scheduleStartDate === form.scheduleEndDate &&
    form.startTime &&
    form.endTime <= form.startTime
  ) {
    errors.endTime = "End time must be after the start time.";
  }
  return errors;
};
